نسخة Firebase Test منفصلة عن التطبيق العامل.

مهم:
- applicationId مختلف: com.walhero.siramowathaba.firebase.test
- لذلك تتنصّب بجانب التطبيق العامل ولا تلمسه.
- لأنها تطبيق مستقل، لا تقرأ تلقائيًا localStorage الخاص بالتطبيق العامل.
- استعملها للتجربة أولًا: استورد/أدخل بيانات فيها ثم ارفع إلى Firebase، وافتح الموقع لاسترجاعها.
- بعد نجاح التجربة، يمكن دمج نفس المزامنة في التطبيق العامل كتحديث آمن.

المزامنة ترفع كل مفاتيح localStorage الخاصة بالتطبيق: sira_* و abs_*.
Firestore path: institutions / sira2 / state / main
