نسخة رجوع آمنة إلى v10 السليمة بدون Firebase.
هذه النسخة مبنية من SiraMowathaba_Model2_V35_SIGNED_KEY_VERIFY_EDIT_BEFORE_PRINT_v10.zip.
لم تتم إضافة Firebase أو أي تعديل جديد.
تم فقط رفع versionCode إلى 12 حتى تقبل التثبيت كتحديث فوق النسخة المخربة v11 دون حذف التطبيق.
نفس applicationId ونفس مفتاح التوقيع الثابت.
